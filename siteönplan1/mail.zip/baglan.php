


<!-- $baglan=mysqli_connect("localhost","root","","üyelik");

// if (!$baglan) {
//     die("Veritabanı Bağlantı Hasası : ". mysqli_connect_errno());
// }else{                                      //mysqli_connect_error()
//     echo "Veritabanı Bağlantısı Başarılı"."<br>";
// }

// mysqli_close($baglan);

// echo "<br><br>Veritabanı Bağlantısı Bitirildi."; -->

<?php
$baglan=mysqli_connect("localhost","root","","final2");


// if (!$baglan) {
//     die("Veritabanı Bağlantı Hasası : ". mysqli_connect_errno());
// }else{                                      //mysqli_connect_error()
//     echo "Veritabanı Bağlantısı Başarılı"."<br>";
// }


?>